# KLUE定位baseline：必须补充的复现审查

> 文档分类：审计记录（保留其核查时间与适用范围）。2026-10-25整理；原文数字和历史记录保留。

日期：2026-10-22；实现更新2026-10-23。状态：原生神经元重实现与测试已完成，正式模型实测尚待exp015门检，不能填写性能分数。

## 名称与当前缺口

FaithUn是现有数据集/评测工作；KLUE是该论文提出的Knowledge-localized Unlearning。
它不等于ICLR2026的CLUE。exp008/009已完成GA、GradDiff、NPO、SimNPO、RMU-LoRA，
没有KLUE。KLUE现为必须补齐的定位对照，不再仅为可选讨论项。

官方论文：ACL2025.emnlp-main.657，arXiv2502.19207v2。
已阅读原文Section4和AppendixB.3。GitHub API对yny0506/faithun main递归清单核对：
LICENSE、README、dataset/FaithUn_Dataset.json及三个split；未见KLUE训练/归因代码。
“未见实现”是这次公开仓库检查结果，不等于作者永久没有其他实现或可联系获取。

## 必须保留的方法环节

1. 神经元知识归因：对模型答案概率的activation-times-gradient，token维max-pooling。
2. 表层知识正则：保留同一个答案，从forget/retain池采样N个失配问题；其归因负值截零，
   按I=A-alpha*mean(A_mismatch_positive)扣除只对答案本身敏感的部分。
3. 每轮选择尚满足知识记忆判据的未遗忘样本，避免继续训练已遗忘样本。
4. 全目标FFN层按知识归因选择top5%神经元，只让相关参数梯度更新。

原文实验给出alpha10、N5、batch4、最大150epochs，遗忘/保留损失权重.7/1，
在UA<=.33时earlystop并搜索能达到该值的低学习率。这不同于当前114步/LoRA/原始QA
的先导协议，不能不披露地称为同一配置或官方复现。

## 实现冻结前必须解决

- gated MLP的“神经元”落在何处（中间激活/输出）及mask对应权重行列；不能靠矩阵
  名称任意选择。真实原文归因是答案概率，不得暗换成平均logprob再称完全一致。
- 批内归因聚合、token范围、失配问题排除规则、全层top比例与平局规则。
- 直接答题的记忆判据、停机和预算：原配方与114步适配应分轨报告。
- 原始full-weight神经元mask与LoRA参数几何不同，若做LoRA版必须标KLUE-adapted；
  原生版需评估24GB训练内存和optimizer状态，不能用OOM后的任意缩减替代原法。
- Qwen3.5混合注意力与Llama分别枚举实际FFN；先完成toy归因/掩码不泄漏、
  固定失配池、实模反向、保存重载和小规模训练检查。

## 后续运行合同

2026-10-23实际入口：exp/train/reproduction_losses.py 与 reproduce_all_baselines.py。
实现概率activation-times-gradient、失配归因正则、每轮未遗忘筛选、全局top5%与原生FFN掩码更新；
gated-MLP神经元映射和CPU掩码Adam为显式约定，不能声称作者代码逐位复现。
KLUE不提供冒充原法的LoRA分支。归因不改参数、掩码无泄漏/无动量越界、原生权重切片保存恢复均有测试。
正式训练前须实际模型smoke通过；新结果只进入exp015独立目录。

审查和实现后另建实验卡、源快照和独立run；不修改正在跑的C2或历史baseline。
优先Llama3.2-3B验证，再Qwen3.5-4B。同模型同题目先导口径与后续完整89路径均报告，
提供原配方与预算适配差异、定位开销、训练参数数和F0/F1数据权限。
比较表当前显示KLUE待复现、不参加排名。没有以简单随机/top-k掩码冒充该baseline。
