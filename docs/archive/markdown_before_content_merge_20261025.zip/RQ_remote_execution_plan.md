# Local and remote RQ validation plan

> 文档分类：研究方案（不是已完成实验结论）。2026-10-25整理；原文数字和历史记录保留。

Date: 2026-10-22. Status: preparation, not a completed experiment.

## Provisioned snapshot

- Remote project: `/root/autodl-tmp/www2027_edit_20261022_141052`.
- Remote interpreter: `/root/miniconda3/bin/python` (Python 3.12.3).
- Hardware: RTX 4090 24GB; PyTorch 2.8.0+cu128. CUDA tensor smoke test passed.
- Initial 367 synchronized files passed SHA256 verification. Three supplemental
  historical-input/comparison files are listed in the expanded remote manifest.
- Includes current uncommitted source; tracked changes also saved as
  `local_worktree.patch`. The remote `sync_manifest.json` is the source inventory.
- Model weights/checkpoints and historical run trees were not transferred.
- Remote training has not started. Model availability and model/data preflight
  remain mandatory before training.

## Evidence audit

RQ definitions follow `docs/GSU小论文大纲.md`.

| RQ | Existing evidence | Remaining evidence |
|---|---|---|
| RQ1: residual multi-hop recall | exp006 A0/A1 and historical base-model evaluations | Matched base-model, F0 direct/paraphrase and multi-hop per-item reporting |
| RQ2: F0-only structure guidance | exp006 A2/A3; exp007 B screen in progress | Effective final candidate, matched baselines, independent evaluation and repeated seeds |
| RQ3: structure specificity | exp006 A2R/A3R; exp007 random controls scheduled | Budget-matched fact/component/direction controls and repeatability |

These RQs have related exploratory experiments; none is hereby declared fully validated.
Do not interpret the historical /12 damage slice as the primary forgetting metric.

## Execution allocation

- Local: preserve the active exp007 batch and its frozen files; finish B0/B1/B2/B3/B2R/B3R before selecting a candidate.
- Remote: synchronize a separate source snapshot; verify dependencies, CUDA, self-tests and frozen-input preflight first.
- Remote first training gate: replicate a 1.5B baseline on identical inputs before comparing machines or changing model size.
- Subsequent remote work: matched 3B baselines/candidates and repeated seeds after a new experiment card fixes method, inputs, metrics, null control and budget.
- Do not launch duplicate exploratory training simply because another GPU is available.

## Confirmation design gates

For RQ1, compare base model, F0-only baseline and F0+F1 reference on the same questions.
For RQ2, use a frozen Q_multi recall rate as the primary endpoint (lower is better),
with the F0-only baseline as primary comparator. Report direct recall, answer-only
logprob and MCQA margin separately; MCQA correctness alone does not establish reasoning.
For RQ3, require the selected method to outperform matched random controls across
predeclared seeds. Bootstrap at cluster/path level, not over dependent paraphrases.
No confirmatory training is authorized by this plan alone: first complete a card
with exact evaluation membership, seeds, steps, expected pattern and success criteria.
This does not change historical exp006/exp007 screening metrics or gates.

## Reproducibility

Remote Python/packages may differ from local; install using remote `python -m pip`.
Preserve the preinstalled CUDA-capable PyTorch when compatible. Record actual package
versions, GPU/driver, code SHA256, dataset/model hashes, command, seed and configuration.
Within a comparison all variants use the same environment. Treat a cross-machine
baseline discrepancy as a diagnostic issue before attributing it to the method.
Keep remote outputs in new run directories and download results without overwriting
local historical runs. Never store SSH passwords in project files or manifests.
