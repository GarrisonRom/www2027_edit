# -*- coding: utf-8 -*-
"""GSU retain coverage and cumulative protection experiments.

Modes:
  COV16: sample 16 fresh retain anchors per update and project AdamW's
         realized displacement onto their individual local half-spaces.
  CUM16: keep one 16-anchor memory bank and add a linearized cumulative floor:
         each anchor's current answer log probability may not fall below its
         initial value after the corrected update.

Both modes preserve the original forget-gradient -> AdamW proposal and leave
AdamW moment state unchanged.  Dykstra's algorithm projects onto the
intersection of half-spaces without adding a QP dependency.
"""
import argparse
import json
import random
import sys
from pathlib import Path

import torch
from peft import LoraConfig, get_peft_model
from transformers import AutoModelForCausalLM, AutoTokenizer

TE = Path(__file__).resolve().parent
sys.path.insert(0, str(TE))
sys.path.insert(0, str(TE.parent / "damage"))
import train_eval as te
import component_ablation as ca
from train_gsu import lp_masked
from diagnose_gsu_m3 import (
    EPOCHS,
    LR,
    OUT,
    TARGET_MODULES,
    clone_grad_tuple,
    clone_param_grads,
    scalar_map_dot,
    scalar_map_norm2,
    sha1_text,
)

N_ANCHOR = 16
PROJECTION_TOL = 1e-8
FINAL_VIOLATION_TOL = 1e-5
MAX_DYKSTRA_CYCLES = 3000
DYKSTRA_COEFF_TOL = 1e-10


def _gram_and_rhs(params, anchor_grads, delta, targets):
    count = len(anchor_grads)
    gram = [[0.0 for _ in range(count)] for _ in range(count)]
    raw_dots = []
    for i in range(count):
        raw_dots.append(scalar_map_dot(params, anchor_grads[i], delta))
        for j in range(i, count):
            value = scalar_map_dot(params, anchor_grads[i], anchor_grads[j])
            gram[i][j] = value
            gram[j][i] = value
    gram_tensor = torch.tensor(gram, dtype=torch.float64)
    rhs = torch.tensor(raw_dots, dtype=torch.float64) - torch.tensor(
        targets, dtype=torch.float64
    )
    return gram_tensor, rhs, raw_dots


def dykstra_coefficients(gram, rhs, max_cycles=MAX_DYKSTRA_CYCLES):
    """Project delta onto A z >= h in the span of anchor gradients.

    `rhs` is A delta - h.  If z=delta+A^T c, each half-space constraint is
    rhs + gram @ c >= 0.  The coefficient-space Dykstra loop is exact in the
    limit and handles 16 constraints without enumerating 2^16 active sets.
    """
    count = int(rhs.numel())
    coefficients = torch.zeros(count, dtype=torch.float64)
    dykstra_corrections = torch.zeros((count, count), dtype=torch.float64)
    diagonal = torch.diag(gram).clamp_min(1e-20)

    if bool((rhs >= -PROJECTION_TOL).all()):
        return coefficients, rhs, 0, True

    for cycle in range(1, max_cycles + 1):
        previous = coefficients.clone()
        for i in range(count):
            y = coefficients + dykstra_corrections[i]
            y_constraints = rhs + gram @ y
            z = y.clone()
            if float(y_constraints[i]) < 0.0:
                z[i] += float(-y_constraints[i] / diagonal[i])
            dykstra_corrections[i] = y - z
            coefficients = z

        final_constraints = rhs + gram @ coefficients
        coefficient_change = float((coefficients - previous).abs().max())
        coefficient_scale = max(1.0, float(coefficients.abs().max()))
        if (
            float(final_constraints.min()) >= -PROJECTION_TOL
            and coefficient_change <= DYKSTRA_COEFF_TOL * coefficient_scale
        ):
            return coefficients, final_constraints, cycle, True

    final_constraints = rhs + gram @ coefficients
    return coefficients, final_constraints, max_cycles, False


def apply_coefficient_correction(params, anchor_grads, coefficients):
    with torch.no_grad():
        for anchor_index, coefficient in enumerate(coefficients.tolist()):
            if abs(coefficient) <= 1e-12:
                continue
            for p in params:
                p.add_(anchor_grads[anchor_index][p], alpha=float(coefficient))


def anchor_gradients(params, model, tok, anchors):
    grads = []
    for rq, ra in anchors:
        lp = lp_masked(model, tok, rq, ra)
        values = torch.autograd.grad(
            lp, params, allow_unused=True, retain_graph=False
        )
        grads.append(clone_grad_tuple(params, values))
    return grads


def anchor_logprobs(model, tok, anchors):
    with torch.no_grad():
        return [float(lp_masked(model, tok, rq, ra)) for rq, ra in anchors]


def train_and_diagnose(run_dir, mode):
    run_dir.mkdir(parents=True, exist_ok=True)
    diagnostics_path = run_dir / "diagnostics.jsonl"
    epoch_path = run_dir / "epoch_metrics.jsonl"
    metrics_path = run_dir / "metrics.json"

    random.seed(te.SEED)
    torch.manual_seed(te.SEED)

    data = json.load(open(te.DATA, encoding="utf-8"))["data"]
    clusters = te.build_clusters(data)
    forget_idx = [int(x) for x in (te.SPLITS / "forget_set_split.txt").read_text().split()]
    retain_idx = [int(x) for x in (te.SPLITS / "retaining_set_split.txt").read_text().split()][:33]
    f1 = json.load(open(OUT / "F1.json", encoding="utf-8"))["F_star"]
    cands = json.load(open(OUT / "candidates.json", encoding="utf-8"))["facts"]

    tok = AutoTokenizer.from_pretrained(te.MODEL)
    retain_ex = [
        (
            clusters[i][2]["hop1_unlearn"]["questions"][0],
            clusters[i][2]["hop1_unlearn"]["answers"],
        )
        for i in retain_idx
    ]
    forget_ex = te.make_group_examples("G2", clusters, forget_idx, f1, cands)

    base = AutoModelForCausalLM.from_pretrained(
        te.MODEL, dtype=torch.bfloat16, device_map="cuda"
    ).eval()
    for p in base.parameters():
        p.requires_grad = False
    model = get_peft_model(
        base,
        LoraConfig(
            r=8,
            lora_alpha=16,
            lora_dropout=0.0,
            bias="none",
            task_type="CAUSAL_LM",
            target_modules=TARGET_MODULES,
        ),
    )
    model.train()
    params = [p for p in model.parameters() if p.requires_grad]
    opt = torch.optim.AdamW(params, lr=LR)
    rng = random.Random(te.SEED)

    memory_anchors = None
    memory_initial_lps = None
    if mode == "CUM16":
        memory_anchors = rng.sample(retain_ex, N_ANCHOR)
        memory_initial_lps = anchor_logprobs(model, tok, memory_anchors)

    epoch_rows = []
    total_rows = 0
    total_corrections = 0
    projection_failures = 0
    dykstra_failures = 0

    with open(diagnostics_path, "w", encoding="utf-8") as diag:
        for ep in range(EPOCHS):
            random.Random(te.SEED + ep).shuffle(forget_ex)
            epoch_rows_raw = []
            total_forget = 0.0
            for step, (q, a) in enumerate(forget_ex):
                opt.zero_grad()
                loss_f = lp_masked(model, tok, q, a)
                if loss_f is None:
                    continue
                loss_f.backward()
                g_f = clone_param_grads(params)

                if mode == "COV16":
                    anchors = rng.sample(retain_ex, N_ANCHOR)
                else:
                    anchors = memory_anchors

                opt.zero_grad()
                lps = [lp_masked(model, tok, rq, ra) for rq, ra in anchors]
                torch.stack(lps).sum().backward()
                g_r = clone_param_grads(params)
                lp_before = [float(lp.detach()) for lp in lps]
                anchor_grads = anchor_gradients(params, model, tok, anchors)

                for p in params:
                    p.grad = g_f[p]
                before = [p.detach().clone() for p in params]
                opt.step()
                delta_raw = {
                    p: p.detach().float() - old.float()
                    for p, old in zip(params, before)
                }
                raw_anchor_dots = [
                    scalar_map_dot(params, ga, delta_raw)
                    for ga in anchor_grads
                ]
                lp_after_raw = anchor_logprobs(model, tok, anchors)

                if mode == "COV16":
                    targets = [0.0] * len(anchors)
                    floor_values = [None] * len(anchors)
                    cumulative_targets = [0.0] * len(anchors)
                else:
                    floor_values = [
                        initial - current
                        for initial, current in zip(memory_initial_lps, lp_before)
                    ]
                    cumulative_targets = [max(0.0, v) for v in floor_values]
                    targets = cumulative_targets

                gram, rhs, raw_dots = _gram_and_rhs(
                    params, anchor_grads, delta_raw, targets
                )
                coefficients, solver_constraints, cycles, converged = (
                    dykstra_coefficients(gram, rhs)
                )
                if not converged:
                    dykstra_failures += 1
                    raise RuntimeError(
                        f"Dykstra projection did not converge: mode={mode}, "
                        f"epoch={ep + 1}, step={step + 1}, "
                        f"min={float(solver_constraints.min())}"
                    )
                apply_coefficient_correction(params, anchor_grads, coefficients)
                corrected = any(abs(v) > 1e-12 for v in coefficients.tolist())
                if corrected:
                    total_corrections += 1

                delta_final = {
                    p: p.detach().float() - old.float()
                    for p, old in zip(params, before)
                }
                final_anchor_dots = [
                    scalar_map_dot(params, ga, delta_final)
                    for ga in anchor_grads
                ]
                lp_after_final = anchor_logprobs(model, tok, anchors)
                final_delta_norm2 = scalar_map_norm2(params, delta_final)
                raw_delta_norm2 = scalar_map_norm2(params, delta_raw)
                correction = {
                    p: delta_final[p] - delta_raw[p]
                    for p in params
                }
                correction_norm2 = scalar_map_norm2(params, correction)
                row = {
                    "mode": mode,
                    "epoch": ep + 1,
                    "step": step + 1,
                    "forget_question_sha1": sha1_text(q),
                    "forget_lp": float(loss_f.detach()),
                    "anchor_count": len(anchors),
                    "anchor_question_sha1": [sha1_text(rq) for rq, _ in anchors],
                    "anchor_initial_lp": memory_initial_lps,
                    "anchor_lp_before": lp_before,
                    "anchor_lp_after_raw_adamw": lp_after_raw,
                    "anchor_lp_after_correction": lp_after_final,
                    "anchor_lp_delta_raw": [
                        b - a for a, b in zip(lp_before, lp_after_raw)
                    ],
                    "anchor_lp_delta_final": [
                        b - a for a, b in zip(lp_before, lp_after_final)
                    ],
                    "cumulative_floor_gap_before": floor_values,
                    "cumulative_targets": cumulative_targets,
                    "aggregate_g_r_delta_raw_dot": scalar_map_dot(
                        params, g_r, delta_raw
                    ),
                    "aggregate_g_r_delta_final_dot": scalar_map_dot(
                        params, g_r, delta_final
                    ),
                    "raw_anchor_dot_delta": raw_anchor_dots,
                    "final_anchor_dot_delta": final_anchor_dots,
                    "raw_anchor_conflict": [d < 0.0 for d in raw_anchor_dots],
                    "final_anchor_conflict": [d < 0.0 for d in final_anchor_dots],
                    "final_anchor_violation_tol": [
                        d - target < -FINAL_VIOLATION_TOL
                        for d, target in zip(final_anchor_dots, cumulative_targets)
                    ],
                    "correction_applied": corrected,
                    "coefficients": coefficients.tolist(),
                    "solver_constraints": solver_constraints.tolist(),
                    "solver_cycles": cycles,
                    "raw_delta_norm": max(raw_delta_norm2, 0.0) ** 0.5,
                    "final_delta_norm": max(final_delta_norm2, 0.0) ** 0.5,
                    "correction_norm": max(correction_norm2, 0.0) ** 0.5,
                    "correction_to_raw_norm_ratio": max(correction_norm2, 0.0) ** 0.5
                    / max(raw_delta_norm2, 1e-12) ** 0.5,
                }
                diag.write(json.dumps(row, ensure_ascii=False) + "\n")
                diag.flush()
                epoch_rows_raw.append(row)
                total_forget += float(loss_f.detach())
                total_rows += 1

            anchor_total = sum(r["anchor_count"] for r in epoch_rows_raw)
            epoch_summary = {
                "mode": mode,
                "epoch": ep + 1,
                "steps": len(epoch_rows_raw),
                "forget_lp_mean": total_forget / max(len(epoch_rows_raw), 1),
                "raw_aggregate_conflict_rate": sum(
                    r["aggregate_g_r_delta_raw_dot"] < 0.0
                    for r in epoch_rows_raw
                ) / max(len(epoch_rows_raw), 1),
                "correction_rate": sum(
                    r["correction_applied"] for r in epoch_rows_raw
                ) / max(len(epoch_rows_raw), 1),
                "raw_anchor_conflict_rate": sum(
                    sum(r["raw_anchor_conflict"]) for r in epoch_rows_raw
                ) / max(anchor_total, 1),
                "final_anchor_conflict_rate": sum(
                    sum(r["final_anchor_conflict"]) for r in epoch_rows_raw
                ) / max(anchor_total, 1),
                "final_anchor_violation_rate_tol": sum(
                    sum(r["final_anchor_violation_tol"])
                    for r in epoch_rows_raw
                ) / max(anchor_total, 1),
                "raw_mean_anchor_lp_delta": sum(
                    sum(r["anchor_lp_delta_raw"]) / r["anchor_count"]
                    for r in epoch_rows_raw
                ) / max(len(epoch_rows_raw), 1),
                "final_mean_anchor_lp_delta": sum(
                    sum(r["anchor_lp_delta_final"]) / r["anchor_count"]
                    for r in epoch_rows_raw
                ) / max(len(epoch_rows_raw), 1),
                "mean_correction_to_raw_norm_ratio": sum(
                    r["correction_to_raw_norm_ratio"] for r in epoch_rows_raw
                ) / max(len(epoch_rows_raw), 1),
                "mean_solver_cycles": sum(
                    r["solver_cycles"] for r in epoch_rows_raw
                ) / max(len(epoch_rows_raw), 1),
            }
            epoch_rows.append(epoch_summary)
            with open(epoch_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(epoch_summary, ensure_ascii=False) + "\n")
            print(json.dumps(epoch_summary, ensure_ascii=False), flush=True)

            ckpt_dir = run_dir / "checkpoints"
            ckpt_dir.mkdir(exist_ok=True)
            torch.save(
                {n: p.detach().cpu() for n, p in model.named_parameters() if "lora" in n},
                ckpt_dir / f"ep{ep + 1}.pt",
            )

    adapter_dir = run_dir / "adapter"
    model.save_pretrained(adapter_dir)
    model.eval()
    five = te.evaluate(model, tok, clusters, forget_idx, retain_idx)
    sets, qa = ca.build_sets()
    six = ca.eval_sets(model, tok, sets, qa)
    six_serialized = {
        k: {
            "n": int(v["n"]),
            "mean_lp": float(v["mean_lp"]),
            "mean_correct": float(v["mean_correct"]),
        }
        for k, v in six.items()
    }
    metrics = {
        "five_set": {"group": f"GSU_{mode}_DIAG", **five},
        "six_set": {"group": f"GSU_{mode}_DIAG", "sets": six_serialized},
        "diagnostics": {
            "mode": mode,
            "steps": total_rows,
            "corrections": total_corrections,
            "projection_failures": projection_failures,
            "dykstra_failures": dykstra_failures,
            "epochs": epoch_rows,
            "raw_jsonl": str(diagnostics_path),
            "algorithm": {
                "COV16": "16 fresh retain anchors per update with individual local half-space update projection",
                "CUM16": "persistent 16-anchor bank with individual local constraints and zero-drop cumulative log-probability floor",
            }[mode],
            "solver": "coefficient-space Dykstra projection onto half-space intersection",
            "optimizer_moments": "unchanged by post-hoc correction",
        },
    }
    with open(metrics_path, "w", encoding="utf-8") as f:
        json.dump(metrics, f, ensure_ascii=False, indent=2)
    print(
        json.dumps(
            {
                "saved": str(metrics_path),
                "mode": mode,
                "steps": total_rows,
                "corrections": total_corrections,
                "projection_failures": projection_failures,
                "dykstra_failures": dykstra_failures,
            },
            ensure_ascii=False,
        ),
        flush=True,
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", required=True, choices=["COV16", "CUM16"])
    ap.add_argument("--run_dir", required=True)
    args = ap.parse_args()
    train_and_diagnose(Path(args.run_dir).resolve(), args.mode)


if __name__ == "__main__":
    main()
