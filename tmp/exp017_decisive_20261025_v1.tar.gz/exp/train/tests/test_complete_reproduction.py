import copy
from pathlib import Path
import sys
from types import SimpleNamespace
import pytest
import torch
import torch.nn.functional as F

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import reproduction_losses as r
import reproduce_all_baselines as runner
import native_delta_checkpoints as native_delta


class MLP(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.gate_proj=torch.nn.Linear(4,6,bias=False)
        self.up_proj=torch.nn.Linear(4,6,bias=False)
        self.down_proj=torch.nn.Linear(6,4,bias=False)
    def forward(self,x):
        return self.down_proj(F.silu(self.gate_proj(x))*self.up_proj(x))


class Layer(torch.nn.Module):
    def __init__(self):
        super().__init__();self.mlp=MLP()
    def forward(self,x):return x+self.mlp(x)


class Toy(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.embed=torch.nn.Embedding(127,4)
        self.model=torch.nn.Module()
        self.model.layers=torch.nn.ModuleList([Layer() for _ in range(8)])
        self.head=torch.nn.Linear(4,127)
    @property
    def device(self):return self.head.weight.device
    def forward(self,input_ids,labels=None,**kwargs):
        x=self.embed(input_ids)
        for layer in self.model.layers:x=layer(x)
        logits=self.head(x)
        loss=None if labels is None else F.cross_entropy(logits[:,:-1].transpose(1,2),labels[:,1:],ignore_index=-100)
        return SimpleNamespace(logits=logits,loss=loss)


def batch():
    ids=torch.tensor([[1,2,3,4,5]])
    return {'input_ids':ids,'labels':torch.tensor([[-100,-100,3,4,5]]),'attention_mask':torch.ones_like(ids)}


@pytest.mark.parametrize('method', [x for x in r.METHODS if x not in ('KLUE','RMU')])
def test_upstream_loss_backward_and_reference_cache(method):
    torch.manual_seed(5);model=Toy();b=batch()
    bank=runner.ReferenceBank();bank.capture(model,[b])
    config=r.profile(method,'matched_lora')
    trainer=r.bind_trainer(config,model,bank)
    if method=='PDU':trainer.retain_loss_eps=0.
    f={'original':b,'alternate':dict(b,labels=torch.tensor([[-100,-100,6,7,8]]))} if method.startswith('DPO') else b
    value=trainer.compute_loss(model,{'forget':f,'retain':b})
    assert torch.isfinite(value)
    value.backward()
    assert model.head.weight.grad is not None
    assert torch.isfinite(model.head.weight.grad).all()
    with torch.no_grad():model.head.weight.add_(.01)
    # Cache must still return pre-update base output, not the current trainable model.
    assert not torch.equal(bank(**b).logits,model(**b).logits)


@pytest.mark.parametrize('method', ('GA','GradDiff','NPO','SimNPO'))
def test_basic_loss_and_gradient_against_independent_formula(method):
    torch.manual_seed(4);model=Toy();b=batch()
    bank=runner.ReferenceBank();bank.capture(model,[b])
    with torch.no_grad():model.head.weight.add_(torch.randn_like(model.head.weight)*.01)
    config=r.profile(method,'matched_lora');t=r.bind_trainer(config,model,bank)
    actual=t.compute_loss(model,{'forget':b,'retain':b})
    output=model(**b);ret=output.loss
    nll=r.answer_nll(output,b['labels']);n=int((b['labels'][:,1:]!=-100).sum())
    ref=r.answer_nll(bank(**b),b['labels'])
    if method=='GA':expected=-ret
    elif method=='GradDiff':expected=-nll/n+ret
    elif method=='NPO':expected=-2/config['beta']*F.logsigmoid(config['beta']*(nll-ref))+ret
    else:expected=config['gamma']*(-2/config['beta']*F.logsigmoid(config['beta']*(nll/n-config['delta'])))+ret
    assert torch.allclose(actual,expected,atol=1e-6)
    ga=torch.autograd.grad(actual,model.head.weight,retain_graph=True)[0]
    gb=torch.autograd.grad(expected,model.head.weight)[0]
    assert torch.allclose(ga,gb,atol=1e-6)


def test_ceu_has_no_extra_retain_term():
    cfg=r.profile('CEU','matched_lora');model=Toy();t=r.bind_trainer(cfg,model)
    b=batch();first=t.compute_loss(model,{'forget':b})
    second=t.compute_loss(model,{'forget':b,'retain':dict(b,labels=torch.zeros_like(b['labels']))})
    assert torch.equal(first,second)


def test_yaml_not_constructor_defaults():
    assert r.profile('NPO','matched_lora')['beta']==.1
    cfg=r.profile('SimNPO','matched_lora');assert cfg['beta']==4.5 and cfg['gamma']==.125
    cfg=r.profile('SatImp','matched_lora');assert cfg['gamma']==.1 and cfg['alpha']==1.
    cfg=r.profile('UNDIAL','matched_lora');assert cfg['beta']==10. and cfg['alpha']==0.
    assert r.profile('PDU','matched_lora')['primal_dual'] is True
    assert r.profile('RMU','native')['retain_loss_type']=='EMBED_DIFF'
    with pytest.raises(ValueError):r.profile('KLUE','matched_lora')


def test_rmu_reference_hook_and_embedding_retain():
    model=Toy();b=batch();bank=runner.ReferenceBank();bank.capture(model,[b],use_hidden=True)
    t=r.bind_trainer(r.profile('RMU','matched_lora'),model,bank)
    value=t.compute_loss(model,{'forget':b,'retain':b})
    assert torch.isfinite(value)
    value.backward();assert model.model.layers[0].mlp.up_proj.weight.grad is not None
    assert torch.allclose(t.compute_retain_loss(model,b),torch.zeros(()),atol=1e-7)


def test_probability_attribution_does_not_mutate_parameters():
    model=Toy();before=copy.deepcopy(model.state_dict());mlps=r.gated_mlps(model)
    scores,logp=r.probability_attribution(model,batch(),mlps)
    assert logp<0 and len(scores)==8
    assert all(v.shape==(6,) for v in scores.values())
    assert all(torch.equal(before[k],v) for k,v in model.state_dict().items())
    assert not any(m._forward_pre_hooks for m in [x.down_proj for x in mlps.values()])


def test_regularizer_clips_only_mismatch_negatives():
    result=r.regularized_importance({'a':torch.tensor([2.,-1.])},
             [{'a':torch.tensor([-3.,4.])},{'a':torch.tensor([2.,-5.])}],10.)
    assert torch.equal(result['a'],torch.tensor([-8.,-21.]))


def test_top_fraction_is_global_and_ties_stable():
    scores={'b':torch.tensor([0.,0.]),'a':torch.tensor([0.,0.])}
    first=r.global_neurons(scores,.25)
    assert first['a'].tolist()==[0] and len(first['b'])==0
    scores={'a':torch.tensor([9.,8.]),'b':torch.tensor([1.,0.])}
    result=r.global_neurons(scores,.5)
    assert result['a'].tolist()==[0,1] and len(result['b'])==0


def test_native_neurons_do_not_move_unselected_weights_or_momentum():
    mlp=MLP();optimizer=r.NativeNeuronAdam({'x':mlp},.01)
    before=copy.deepcopy(mlp.state_dict())
    for p in mlp.parameters():p.grad=torch.ones_like(p)
    optimizer.step({'x':torch.tensor([1])})
    after=copy.deepcopy(mlp.state_dict())
    for field in ('gate_proj','up_proj'):
        assert torch.equal(before[field+'.weight'][[0,2,3,4,5]],after[field+'.weight'][[0,2,3,4,5]])
        assert not torch.equal(before[field+'.weight'][1],after[field+'.weight'][1])
    assert torch.equal(before['down_proj.weight'][:,[0,2,3,4,5]],after['down_proj.weight'][:,[0,2,3,4,5]])
    optimizer.step({'x':torch.tensor([2])})
    assert torch.equal(after['down_proj.weight'][:,1],mlp.down_proj.weight[:,1])
    assert torch.equal(after['gate_proj.weight'][1],mlp.gate_proj.weight[1])
    saved=optimizer.state_dict()
    assert saved['slices']['x.down_proj']['indices'].tolist()==[1,2]


def test_cpu_adam_matches_torch_adam_on_float32():
    a=torch.nn.Parameter(torch.tensor([1.,2.]));b=torch.nn.Parameter(a.detach().clone())
    opt=runner.CPUAdamW([a],.01,.01);reference=torch.optim.AdamW([b],lr=.01,weight_decay=.01)
    for _ in range(3):
        a.grad=torch.tensor([2.,-3.]);b.grad=a.grad.clone()
        opt.step();reference.step()
        assert torch.equal(a,b)


def test_dpo_same_question_distinct_mismatched_answer():
    import random
    item={'id':'a','question':'question','answer':'answer'}
    mismatch=runner.alternate(item,[dict(item,answer='other')],'DPOmis',random.Random(42))
    assert mismatch['question']==item['question'] and mismatch['answer']!='answer'
    assert runner.alternate(item,[],'DPOrej',random.Random(42))['answer']=="I don't know."


def test_reference_bank_batched_outputs_match_frozen_model():
    model=Toy();first=batch();second=batch()
    second['input_ids']=second['input_ids'].clone()+1
    second['labels']=second['labels'].clone();second['labels'][:,2:]+=1
    bank=runner.ReferenceBank();bank.capture(model,[first,second],use_hidden=True)
    combined={key:torch.cat([first[key],second[key]],dim=0) for key in first}
    actual=bank(**combined);expected=model(**combined)
    assert torch.allclose(actual.logits,expected.logits,atol=1e-6)
    assert torch.allclose(actual.loss,expected.loss,atol=1e-6)


@pytest.mark.parametrize('dtype',[torch.float32,torch.bfloat16])
def test_native_sparse_checkpoint_restores_full_weights(dtype):
    model=Toy().to(dtype);fresh=copy.deepcopy(model);mlps=r.gated_mlps(model)
    optimizer=r.NativeNeuronAdam(mlps,.01)
    selected={key:torch.tensor([1,3]) for key in mlps}
    for parameter in model.parameters():parameter.grad=torch.ones_like(parameter)
    optimizer.step(selected)
    r.restore_native_neurons(fresh,optimizer.state_dict())
    assert all(torch.equal(v,fresh.state_dict()[key]) for key,v in model.state_dict().items())


def test_rmu_variable_length_batch_is_per_sequence_not_cross_broadcast():
    current=torch.tensor([[[2.],[99.]],[[1.],[3.]]],requires_grad=True)
    mask=torch.tensor([[True,False],[True,True]])
    value=r.masked_activation_loss(current,torch.zeros_like(current),mask)
    assert value.item()==4.5
    value.backward()
    assert current.grad[0,1].item()==0


def test_undial_ignored_prompt_positions_have_zero_direct_logit_gradient():
    class LogitModel:
        def __init__(self):self.logits=torch.nn.Parameter(torch.randn(1,5,127))
        def __call__(self,**kw):return SimpleNamespace(logits=self.logits)
    model=LogitModel();teacher=LogitModel()
    value,_=r.undial_answer_loss(model,teacher,batch(),10.)
    grad=torch.autograd.grad(value,model.logits)[0]
    assert torch.equal(grad[:,0],torch.zeros_like(grad[:,0]))
    assert grad[:,1:4].abs().sum()>0
    assert torch.equal(grad[:,4],torch.zeros_like(grad[:,4]))


def test_loss_output_promotion_preserves_gradient():
    logits=torch.randn(1,3,4,dtype=torch.bfloat16,requires_grad=True)
    output=SimpleNamespace(logits=logits,loss=None)
    promoted=runner.fp32_loss_outputs(None,None,output)
    assert promoted.logits.dtype==torch.float32
    promoted.logits.sum().backward()
    assert torch.equal(logits.grad,torch.ones_like(logits))


@pytest.mark.parametrize('dtype',[torch.float32,torch.bfloat16])
def test_lossless_native_delta_roundtrip_and_wrong_base(tmp_path,dtype):
    model=Toy().to(dtype);fresh=copy.deepcopy(model)
    original=native_delta.capture_base(model)
    with torch.no_grad():model.head.weight.add_(.01)
    folder=tmp_path/'checkpoint'
    native_delta.save_delta(model,original,folder)
    native_delta.restore_delta(fresh,folder)
    assert all(torch.equal(value,fresh.state_dict()[key]) for key,value in model.state_dict().items())
    with pytest.raises(RuntimeError,match='Wrong base'):
        native_delta.restore_delta(fresh,folder)

